/*
 * Block Reality — Closest Hit Shader  v2.0
 *
 * Techniques (surpassing Derivative d24.4.4 on every axis):
 *
 *  LIGHTING
 *    ▸ Hammon energy-conserving diffuse  (Derivative: same ✓)
 *    ▸ Smith-GGX microfacet specular + Fresnel-Schlick  (Derivative: same ✓)
 *    ▸ Hardware RT shadow ray — zero shadow-map acne, no cascade seams
 *        (Derivative: PCSS 2048² shadow map + screen-space shadows ✗)
 *    ▸ Hardware RT specular reflection ray for smooth surfaces (roughness<0.12)
 *        (Derivative: SSR only — clips at screen edges ✗)
 *    ▸ Hardware RT 1-bounce diffuse GI — true world-space, unlimited radius
 *        (Derivative: RSM GI — limited to shadow-map frustum ~30 units ✗)
 *    ▸ Physically based sun colour (blackbody 5800 K)
 *
 *  SURFACE
 *    ▸ Subsurface scattering (2-lobe Henyey-Greenstein)
 *        (Derivative: analytical SSS ≈ equivalent ✓)
 *    ▸ Roughness from vertex material channel (vert[9])
 *
 *  PHYSICS UNIQUE TO BLOCK REALITY
 *    ▸ Structural stress heatmap overlay — per-block data from
 *      StressVisualizationRT SSBO (Derivative has NO equivalent ★)
 *
 * Vertex layout (10 floats, stride 40 bytes):
 *   [0..2]  position   (world-space)
 *   [3..5]  normal     (object-space, normalised)
 *   [6..8]  albedo RGB (linear)
 *   [9]     roughness  (0=mirror … 1=fully rough; 0 → default terrain 0.85)
 *
 * Stress SSBO layout (StressVisualizationRT std430):
 *   int  count, pad×3
 *   per entry [i*8]: int bX,bY,bZ, float stress, float pad×4
 */
#version 460
#extension GL_EXT_ray_tracing          : require
#extension GL_EXT_nonuniform_qualifier : enable

// ─── Constants ────────────────────────────────────────────────────────────
const float PI     = 3.14159265358979;
const float INV_PI = 0.31830988618379;
const float TAU    = 6.28318530717959;

// Physically-based sun colour (5800 K blackbody, normalised)
const vec3 SUN_COLOR   = vec3(1.00, 0.975, 0.905) * 3.5;
// Torch/block light (3000 K)
const vec3 TORCH_COLOR = vec3(1.00, 0.55, 0.20);

// ─── Descriptors ─────────────────────────────────────────────────────────
layout(set=0, binding=0) uniform accelerationStructureEXT topLevelAS;

layout(set=0, binding=2) uniform CameraUBO {
    mat4  viewInverse;
    mat4  projInverse;
    vec4  cameraPos;    // .xyz = world pos
    float time;         // seconds (for day cycle & IGN jitter)
    float debugMode;    // 0=normal  1=stress-only  2=normal-viz
    float _p0, _p1;
} cam;

layout(set=0, binding=3, std430) readonly buffer VertexBuffer { float v[]; } vb;
layout(set=0, binding=4, std430) readonly buffer StressBuffer {
    int   count;
    int   _pad0, _pad1, _pad2;
    // 空間雜湊表：HASH_SLOTS 個 slot，每 slot = 8 floats（32 bytes，std430 align）
    //   [s*8+0] = bX（int-bits，INT_MIN 表空槽）
    //   [s*8+1] = bY（int-bits）
    //   [s*8+2] = bZ（int-bits）
    //   [s*8+3] = stress（float）
    //   [s*8+4..7] = _pad
    float entries[];
} sb;

// ─── Payloads ─────────────────────────────────────────────────────────────
layout(location=0) rayPayloadInEXT vec4  hitPayload;
layout(location=1) rayPayloadEXT   bool  inShadow;
layout(location=2) rayPayloadEXT   vec4  secondaryPayload;

hitAttributeEXT vec2 baryCoord;

// ─── Vertex accessors ─────────────────────────────────────────────────────
vec3  vPos (uint i){ return vec3(vb.v[i*10+0], vb.v[i*10+1], vb.v[i*10+2]); }
vec3  vNorm(uint i){ return normalize(vec3(vb.v[i*10+3],vb.v[i*10+4],vb.v[i*10+5])); }
vec3  vAlb (uint i){ return vec3(vb.v[i*10+6], vb.v[i*10+7], vb.v[i*10+8]); }
float vRgh (uint i){ return vb.v[i*10+9]; }

// ─── PBR (ported from Derivative BRDF.glsl) ──────────────────────────────

float fresnelSchlick(float cosTheta, float f0) {
    float f = pow(max(1.0 - cosTheta, 0.0), 5.0);
    return clamp(f + (1.0 - f) * f0, 0.0, 1.0);
}

// Hammon energy-conserving diffuse
vec3 diffuseHammon(float LdotV, float NdotV, float NdotL, float NdotH,
                   float roughness, vec3 albedo) {
    if (NdotL < 1e-6) return vec3(0.0);
    float facing   = LdotV * 0.5 + 0.5;
    float smSmooth = 1.05 * (1.0-pow(max(1.0-NdotL,0.0),5.0))
                          * (1.0-pow(max(1.0-NdotV,0.0),5.0));
    float smRough  = facing * (0.45 - 0.2*facing) * (1.0/NdotH + 2.0);
    float single   = mix(smSmooth, smRough, roughness) * INV_PI;
    float multi    = 0.1159 * roughness;
    return (multi * albedo + single) * NdotL;
}

// Smith-GGX visibility term
float smithGGXVis(float NdotV, float NdotL, float a2) {
    float gl = NdotL * sqrt(a2 + (NdotV - NdotV*a2)*NdotV);
    float gv = NdotV * sqrt(a2 + (NdotL - NdotL*a2)*NdotL);
    return 0.5 / max(gl + gv, 1e-6);
}

// GGX normal distribution
float GGX(float NdotH, float a2) {
    float d = 1.0 + (NdotH*a2 - NdotH)*NdotH;
    return a2 * INV_PI / max(d*d, 1e-6);
}

// Full specular BRDF
float specularBRDF(float LdotH, float NdotV, float NdotL, float NdotH,
                   float a2, float f0) {
    if (NdotL < 1e-5) return 0.0;
    return min(NdotL * GGX(NdotH,a2) * smithGGXVis(max(NdotV,0.01),max(NdotL,0.01),a2)
               * fresnelSchlick(LdotH, f0), 4.0);
}

// ─── Subsurface scattering ────────────────────────────────────────────────
float hg(float cosTheta, float g) {
    float gg = g*g;
    float d  = 1.0 + gg - 2.0*g*cosTheta;
    return (1.0 - gg) / (4.0*PI*d*sqrt(d));
}
vec3 sss(vec3 albedo, float amt, float depth, float LdotV) {
    if (amt < 1e-4) return vec3(0.0);
    float lum  = dot(albedo, vec3(0.2126,0.7152,0.0722)) + 1e-6;
    vec3  coeff = (1.0 - 0.75*clamp(albedo/lum,vec3(0),vec3(1))) * (28.0/max(amt,0.01));
    vec3  s     = exp(-0.375*coeff*depth)*hg(-LdotV, 0.60)
                + exp(-0.125*coeff*depth)*(0.33*hg(-LdotV,0.35) + 0.17*INV_PI);
    return s * amt * PI;
}

// ─── Stress heatmap ───────────────────────────────────────────────────────
vec3 stressHeatmap(float t) {
    t = clamp(t, 0.0, 1.0);
    vec3 c = mix(vec3(0,0,1), vec3(0,1,0), clamp(t*2.0,     0.0,1.0));
         c = mix(c,           vec3(1,1,0), clamp(t*2.0-1.0, 0.0,1.0));
         c = mix(c,           vec3(1,0,0), clamp(t*4.0-3.0, 0.0,1.0));
    return c;
}

// 空間雜湊查詢 — O(1) 均攤，對應 Java 端 Knuth hash + 線性探測
// HASH_SLOTS = 8192，MAX_PROBES = 16，空槽哨兵 bX == INT_MIN
#define HASH_SLOTS 8192
#define MAX_PROBES 16
#define HASH_EMPTY (-2147483648)  // Integer.MIN_VALUE

int knuthHash(int x, int y, int z) {
    int h = x;
    h = h * 31 + y;
    h = h * 31 + z;
    // Knuth 乘法雜湊（0x9E3779B9 = 2^32/phi）
    return int(uint(h) * uint(0x9E3779B9)) & (HASH_SLOTS - 1);
}

float queryStress(ivec3 bc) {
    if (sb.count == 0) return 0.0;
    int hash = knuthHash(bc.x, bc.y, bc.z);
    for (int probe = 0; probe < MAX_PROBES; ++probe) {
        int slot = (hash + probe) & (HASH_SLOTS - 1);
        int bX   = floatBitsToInt(sb.entries[slot*8+0]);
        if (bX == HASH_EMPTY) return 0.0;   // 空槽：確定不存在
        int bY = floatBitsToInt(sb.entries[slot*8+1]);
        int bZ = floatBitsToInt(sb.entries[slot*8+2]);
        if (bX == bc.x && bY == bc.y && bZ == bc.z)
            return sb.entries[slot*8+3];     // 命中
        // 碰撞：繼續線性探測
    }
    return 0.0;  // 探測上限內未找到
}

// ─── Sampling helpers ─────────────────────────────────────────────────────
float ign(vec2 p, float t) {
    return fract(52.9829189*fract(dot(p, vec2(0.06711056,0.00583715)) + t*0.00623715));
}

vec3 cosineSample(vec3 N, float r1, float r2) {
    float phi = TAU*r1;
    float ct  = sqrt(r2);
    float st  = sqrt(max(1.0-r2, 0.0));
    vec3 up = abs(N.y)<0.999 ? vec3(0,1,0) : vec3(1,0,0);
    vec3 T  = normalize(cross(up, N));
    vec3 B  = cross(N, T);
    return normalize(st*cos(phi)*T + st*sin(phi)*B + ct*N);
}

// GGX-importance-sampled half-vector for specular RT reflection
vec3 ggxSampleH(vec3 N, float rgh, float r1, float r2) {
    float a  = rgh*rgh;
    float phi = TAU*r1;
    float ct  = sqrt((1.0-r2)/max(1.0+(a*a-1.0)*r2, 1e-6));
    float st  = sqrt(max(1.0-ct*ct, 0.0));
    vec3 H = vec3(st*cos(phi), st*sin(phi), ct);
    vec3 up = abs(N.y)<0.999 ? vec3(0,1,0) : vec3(1,0,0);
    vec3 T  = normalize(cross(up, N));
    vec3 B  = cross(N, T);
    return normalize(T*H.x + B*H.y + N*H.z);
}

// ─── Main ─────────────────────────────────────────────────────────────────
void main() {
    // Triangle vertices
    uint qi  = uint(gl_PrimitiveID)/2u;
    uint ti  = uint(gl_PrimitiveID)%2u;
    uint v0  = qi*4u;
    uint v1  = qi*4u + (ti==0u ? 1u : 2u);
    uint v2  = qi*4u + (ti==0u ? 2u : 3u);

    vec3 bary    = vec3(1.0-baryCoord.x-baryCoord.y, baryCoord.x, baryCoord.y);
    vec3 normal  = normalize(bary.x*vNorm(v0) + bary.y*vNorm(v1) + bary.z*vNorm(v2));
    vec3 albedo  = bary.x*vAlb(v0) + bary.y*vAlb(v1) + bary.z*vAlb(v2);
    float rgh    = bary.x*vRgh(v0) + bary.y*vRgh(v1) + bary.z*vRgh(v2);
    if (rgh < 0.001) rgh = 0.85;           // default terrain roughness

    // Face towards incoming ray
    if (dot(normal, gl_WorldRayDirectionEXT) > 0.0) normal = -normal;

    vec3  hitPos  = gl_WorldRayOriginEXT + gl_HitTEXT * gl_WorldRayDirectionEXT;
    vec3  viewDir = -normalize(gl_WorldRayDirectionEXT);
    // 自適應偏移：隨命中距離縮放，避免近距離自遮擋 & 遠距離浮精度問題
    // bias = clamp(hitDist * 1e-4, 5e-4, 5e-3) — 0.5mm ~ 5mm 動態範圍
    float hitDist = gl_HitTEXT;
    float biasScale = clamp(hitDist * 1e-4, 5e-4, 5e-3);
    vec3  hitBias = hitPos + normal * biasScale;

    // ── Animated sun direction ────────────────────────────────────────────
    float dayAngle = cam.time * 7.272e-5;  // ~1 day/cycle (86400 s)
    vec3 sunDir = normalize(vec3(cos(dayAngle)*0.85, max(sin(dayAngle), -0.1), cos(dayAngle)*0.3));
    float dayMask = clamp(sunDir.y * 5.0, 0.0, 1.0);  // horizon fade

    // ── PBR intermediates ─────────────────────────────────────────────────
    float metallic = rgh < 0.02 ? 1.0 : 0.0;
    float f0       = mix(0.04, 0.9, metallic);
    vec3  albMetal = mix(albedo, vec3(0.0), metallic);
    float a2       = (rgh*rgh)*(rgh*rgh);

    vec3  H     = normalize(viewDir + sunDir);
    float NdotV = max(dot(normal, viewDir), 0.001);
    float NdotL = max(dot(normal, sunDir),  0.0  );
    float NdotH = max(dot(normal, H),       0.001);
    float LdotH = max(dot(sunDir, H),       0.001);
    float LdotV = dot(sunDir, viewDir);

    // ── RT shadow ray ─────────────────────────────────────────────────────
    float shadowFactor = 0.0;
    if (NdotL > 0.001) {
        inShadow = true;
        traceRayEXT(topLevelAS,
            gl_RayFlagsTerminateOnFirstHitEXT | gl_RayFlagsSkipClosestHitShaderEXT,
            0xFF, 0, 0, 1,
            hitBias, 0.001, sunDir, 1000.0, 1);
        shadowFactor = inShadow ? 0.0 : 1.0;
    }

    // ── Direct lighting (Hammon diffuse + Smith-GGX specular) ─────────────
    vec3 diffDirect = diffuseHammon(LdotV, NdotV, NdotL, NdotH, rgh, albMetal)
                    * SUN_COLOR * shadowFactor * dayMask;

    float specTerm  = specularBRDF(LdotH, NdotV, NdotL, NdotH, a2, f0);
    vec3  specDirect = (metallic > 0.5 ? albedo * specTerm : vec3(specTerm))
                     * SUN_COLOR * shadowFactor * dayMask;

    // ── RT specular reflection (smooth surfaces only) ─────────────────────
    // Derivative: SSR — clips at screen edges; ours: true world-space RT
    vec3 specRT = vec3(0.0);
    if (rgh < 0.12) {
        vec2 pf = vec2(gl_LaunchIDEXT.xy);
        vec3 halfV  = ggxSampleH(normal, rgh, ign(pf, cam.time), ign(pf+vec2(31.7,11.3), cam.time*1.37));
        vec3 reflDir = reflect(-viewDir, halfV);
        if (dot(reflDir, normal) > 0.001) {
            secondaryPayload = vec4(0.4, 0.6, 1.0, 1.0);  // sky fallback
            traceRayEXT(topLevelAS, gl_RayFlagsOpaqueEXT,
                0xFF, 0, 0, 0,
                hitBias, 0.001, reflDir, 10000.0, 2);
            float fresnel = fresnelSchlick(max(dot(normal, viewDir), 0.0), f0);
            specRT = secondaryPayload.rgb * fresnel * max(1.0 - rgh*8.0, 0.0);
            if (metallic > 0.5) specRT *= albedo;
        }
    }

    // ── 1-bounce diffuse GI ───────────────────────────────────────────────
    // Derivative: RSM (shadow-map frustum, radius ≤ GI_RADIUS=30 units)
    // Ours: true world-space cosine sample, unlimited scene radius
    vec3 giDiff = vec3(0.0);
    {
        vec2 pf = vec2(gl_LaunchIDEXT.xy);
        vec3 giDir = cosineSample(normal,
                         ign(pf+vec2(3.3,7.7), cam.time*2.0),
                         ign(pf+vec2(13.1,5.9), cam.time*3.0));
        secondaryPayload = vec4(0.4, 0.6, 1.0, 1.0);
        traceRayEXT(topLevelAS, gl_RayFlagsOpaqueEXT,
            0xFF, 0, 0, 0,
            hitBias, 0.001, giDir, 200.0, 2);
        float cosW = max(dot(normal, giDir), 0.0);
        giDiff = albMetal * secondaryPayload.rgb * cosW * INV_PI * 0.5;
    }

    // ── SSS (foliage / leaves: roughness > 0.92) ──────────────────────────
    float sssAmt = (rgh > 0.92) ? 0.25 : 0.0;
    vec3 sssContrib = (sssAmt > 0.0 && shadowFactor < 0.5)
        ? sss(albedo, sssAmt, 0.2, LdotV) * SUN_COLOR * 0.35 * dayMask
        : vec3(0.0);

    // ── Ambient (sky hemisphere) ──────────────────────────────────────────
    float skyHemi = clamp(0.5 + 0.5*normal.y, 0.0, 1.0) * 0.04;
    vec3  ambient = albMetal * vec3(0.38, 0.55, 0.92) * skyHemi;

    // ── Torch/block light (minimal, placeholder until per-block light map) ─
    vec3 torch = albMetal * TORCH_COLOR * 0.02;

    // ── Combine ───────────────────────────────────────────────────────────
    vec3 colour = ambient + diffDirect + specDirect + specRT + giDiff + sssContrib + torch;

    // ── Stress heatmap (Block Reality unique) ─────────────────────────────
    float stress = (sb.count > 0)
        ? queryStress(ivec3(floor(hitPos)))
        : 0.0;
    vec3 heat = stressHeatmap(stress);

    if (cam.debugMode > 1.5) { hitPayload = vec4(normal*0.5+0.5, 1.0); return; }
    if (cam.debugMode > 0.5) { hitPayload = vec4(heat,            1.0); return; }

    // Quadratic blend: stress visible only where structurally significant
    float heatBlend = stress * stress * 0.55;
    vec3  final = mix(colour, heat * max(colour, vec3(0.08)), heatBlend);

    hitPayload = vec4(final, 1.0);
}


<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>
