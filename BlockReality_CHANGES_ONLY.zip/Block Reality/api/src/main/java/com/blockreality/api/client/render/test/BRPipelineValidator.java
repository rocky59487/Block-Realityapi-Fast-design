    //  1. 子系統初始化驗證（32 個子系統）
    // ═══════════════════════════════════════════════════════════════

    private static void validateSubsystemInit(List<ValidationResult> results) {
        String cat = "SubsystemInit";

        // 管線自身
        boolean pipelineInit = LODRenderDispatcher.getInstance().isInitialized();
        results.add(new ValidationResult(cat, "BRRenderPipeline",
            pipelineInit,
            pipelineInit ? "管線已初始化" : "管線未初始化！"));

        // 1. FBO Manager
        int fboId = Minecraft.getInstance().getMainRenderTarget().getFramebufferObject();
        results.add(new ValidationResult(cat, "BRFramebufferManager",
            fboId > 0,
            fboId > 0 ? "FBO 系統就緒" : "FBO 未初始化！"));

        // 2. Shader Engine（驗證核心 shader 非 null）
        boolean shadersOk = BRShaderEngine.getGBufferTerrainShader() != null
            && BRShaderEngine.getDeferredLightingShader() != null
            && BRShaderEngine.getFinalShader() != null;
        results.add(new ValidationResult(cat, "BRShaderEngine",
            shadersOk, shadersOk ? "核心 shader 已編譯" : "缺少核心 shader！"));


<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>
