     * 執行所有 Phase 13 整合測試。
     * 必須在 GL context 主執行緒、管線 init() 之後呼叫。
     *
     * @return 測試摘要
     */
    public static TestSummary runAll() {
        if (!LODRenderDispatcher.getInstance().isInitialized()) {
            LOG.error("管線未初始化，無法執行整合測試");
            return new TestSummary(0, 0, 0, 0);
        }

        long startTime = System.currentTimeMillis();
        int totalTests = 0;
        int totalPassed = 0;
        int totalFailed = 0;

        LOG.info("╔══════════════════════════════════════════════════════════╗");
        LOG.info("║  Block Reality Phase 13 — 全管線整合測試               ║");
        LOG.info("║  32 子系統 · 40+ Shader · 15 Pass Composite Chain      ║");
        LOG.info("╚══════════════════════════════════════════════════════════╝");

<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>
