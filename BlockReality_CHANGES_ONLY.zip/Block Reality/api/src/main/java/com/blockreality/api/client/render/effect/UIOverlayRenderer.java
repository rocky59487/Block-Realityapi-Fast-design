        int y = 40; // F3 下方留空
        int lineHeight = 10;
        int bgColor = 0x80000000; // 半透明黑底

        String[] lines = {
            "§6[Block Reality Render Pipeline]",
            String.format("§7Pipeline: §a%s",
                LODRenderDispatcher.getInstance().isInitialized() ? "ON (RT=" +
                    LODRenderDispatcher.getInstance().isRTEnabled() + ")" : "OFF"),
            String.format("§7Frustum: §f%d visible §8/ §c%d culled",
                BROptimizationEngine.getLastCulledCount() > 0
                    ? BROptimizationEngine.getLastCulledCount() : 0,
                BROptimizationEngine.getLastCulledCount()),
            String.format("§7Draw Calls: §f%d  §7Cached Sections: §f%d",
                BROptimizationEngine.getLastDrawCallCount(),
                BROptimizationEngine.getCachedSectionCount()),
            String.format("§7Animations: §f%d active",
                BRAnimationEngine.getActiveControllerCount()),
            String.format("§7Effects: §f%d particles §f%d fragments",
                BREffectRenderer.getPlacementRenderer() != null
                    ? BREffectRenderer.getPlacementRenderer().getActiveParticleCount() : 0,
                BREffectRenderer.getStructuralRenderer() != null
                    ? BREffectRenderer.getStructuralRenderer().getActiveFragmentCount() : 0)
        };

        for (String line : lines) {
            int width = font.width(line);
            gui.fill(x - 1, y - 1, x + width + 1, y + lineHeight - 1, bgColor);
            gui.drawString(font, line, x, y, 0xFFFFFF, false);
            y += lineHeight;
        }
    }

    void cleanup() {
        debugHudEnabled = false;
    }
}


<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>
