	 * 渲染所有可見的 LOD 段落
	 * 應在延遲渲染或正向渲染管道的適當階段調用
	 *
	 * @param projMatrix 投影矩陣
	 * @param viewMatrix 視圖矩陣
	 */
	public static void render(Matrix4f projMatrix, Matrix4f viewMatrix) {
		if (!initialized || lodShaderProgram == null) {
			return;
		}

		lodShaderProgram.bind();

		// 設置全局著色器統一變數
		lodShaderProgram.setUniformMat4("u_projMatrix", projMatrix);
		lodShaderProgram.setUniformMat4("u_viewMatrix", viewMatrix);
		lodShaderProgram.setUniformVec3("u_cameraPos",
			(float) cameraX, (float) cameraY, (float) cameraZ);
		lodShaderProgram.setUniformFloat("u_lodMaxDistance", (float) BRRenderConfig.LOD_MAX_DISTANCE);

		// 蒐集並渲染可見段落
		List<LODSection> visibleSections = collectVisibleSections();

		for (LODSection section : visibleSections) {
			// 跳過未構建的段落
			if (section.vao < 0 || section.indexCount <= 0) {
				continue;
			}

			// 視錐體裁剪最終檢查（視錐體可能已在 update 中變化）
			if (frustumCuller != null && !frustumCuller.testAABB(
				section.minX, section.minY, section.minZ,
				section.maxX, section.maxY, section.maxZ)) {
				continue;
			}

			// 設置段落特定的統一變數
			Matrix4f modelMatrix = new Matrix4f();
			modelMatrix.translation((float) (section.centerX - cameraX), 0, (float) (section.centerZ - cameraZ));
			lodShaderProgram.setUniformMat4("u_modelMatrix", modelMatrix);
			lodShaderProgram.setUniformInt("u_lodLevel", section.lodLevel.index);

			// 渲染段落
			glBindVertexArray(section.vao);
			glDrawElements(GL_TRIANGLES, section.indexCount, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
		}

		lodShaderProgram.unbind();
	}


<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>
